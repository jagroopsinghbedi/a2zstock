export interface Product {
  _id?: string
  id: string
  name: string
  category: string
  cost: number
  quantity: number
  salePrice: number
  purchaseDate: string
  warranty: string
  dealer: string
  notes?: string
}

export interface Category {
  _id?: string
  id: string
  name: string
  description: string
  productCount: number
  createdAt: string
}

export interface Service {
  _id?: string
  id: string
  name: string
  description: string
  price: number
  duration: string
  status: "active" | "inactive"
  formFields?: any[]
}

export interface Order {
  _id?: string
  id: string
  customer: string
  date: string
  total: number
  items: number
  status: "completed" | "processing" | "cancelled"
  cashier: string
  products: OrderItem[]
  services?: ServiceOrder[]
  discount?: number
  notes?: string
}

export interface OrderItem {
  productId: string
  name: string
  price: number
  quantity: number
}

export interface ServiceOrder {
  serviceId: string
  name: string
  price: number
  customerName: string
  customerPhone: string
  deviceType?: string
  problemDescription?: string
  notes?: string
  status: "pending" | "in-progress" | "completed"
  [key: string]: any
}

