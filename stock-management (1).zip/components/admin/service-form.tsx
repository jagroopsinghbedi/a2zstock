"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { X, Plus, Trash } from "lucide-react"
import type { Service } from "@/lib/types"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"

interface ServiceFormProps {
  service: Service | null
  onSubmit: (data: Service) => void
  onCancel: () => void
}

type FieldType = "text" | "number" | "textarea" | "checkbox" | "radio" | "select"

interface CustomField {
  id: string
  label: string
  type: FieldType
  required: boolean
  options?: string[] // For select, radio, etc.
}

export function ServiceForm({ service, onSubmit, onCancel }: ServiceFormProps) {
  const [formData, setFormData] = useState<Service>({
    id:
      service?.id ||
      `SRV${Math.floor(Math.random() * 10000)
        .toString()
        .padStart(4, "0")}`,
    name: service?.name || "",
    description: service?.description || "",
    price: service?.price || 0,
    duration: service?.duration || "",
    status: service?.status || "active",
    formFields: service?.formFields || [],
  })

  const [customFields, setCustomFields] = useState<CustomField[]>(service?.formFields || [])

  const [newField, setNewField] = useState<CustomField>({
    id: `field_${Date.now()}`,
    label: "",
    type: "text",
    required: false,
    options: [],
  })

  const [newOption, setNewOption] = useState("")

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: name === "price" ? Number.parseFloat(value) || 0 : value,
    }))
  }

  const handleStatusChange = (value: string) => {
    setFormData((prev) => ({ ...prev, status: value as "active" | "inactive" }))
  }

  const handleNewFieldChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setNewField((prev) => ({ ...prev, [name]: value }))
  }

  const handleNewFieldTypeChange = (value: string) => {
    setNewField((prev) => ({ ...prev, type: value as FieldType }))
  }

  const handleNewFieldRequiredChange = (checked: boolean) => {
    setNewField((prev) => ({ ...prev, required: checked }))
  }

  const addOption = () => {
    if (newOption.trim() && newField.options) {
      setNewField((prev) => ({
        ...prev,
        options: [...(prev.options || []), newOption.trim()],
      }))
      setNewOption("")
    }
  }

  const removeOption = (index: number) => {
    setNewField((prev) => ({
      ...prev,
      options: prev.options?.filter((_, i) => i !== index),
    }))
  }

  const addCustomField = () => {
    if (newField.label.trim()) {
      setCustomFields((prev) => [...prev, { ...newField }])
      setNewField({
        id: `field_${Date.now()}`,
        label: "",
        type: "text",
        required: false,
        options: [],
      })
    }
  }

  const removeCustomField = (id: string) => {
    setCustomFields((prev) => prev.filter((field) => field.id !== id))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSubmit({
      ...formData,
      formFields: customFields,
    })
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-lg w-full max-w-4xl max-h-[90vh] overflow-auto">
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="text-xl font-semibold">{service ? "Edit Service" : "Add New Service"}</h2>
          <Button variant="ghost" size="icon" onClick={onCancel}>
            <X className="h-4 w-4" />
          </Button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="id">Service ID</Label>
              <Input id="id" name="id" value={formData.id} onChange={handleChange} disabled />
            </div>

            <div className="space-y-2">
              <Label htmlFor="name">Service Name</Label>
              <Input id="name" name="name" value={formData.name} onChange={handleChange} required />
            </div>

            <div className="space-y-2">
              <Label htmlFor="price">Price</Label>
              <Input
                id="price"
                name="price"
                type="number"
                step="0.01"
                min="0"
                value={formData.price}
                onChange={handleChange}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="duration">Duration</Label>
              <Input
                id="duration"
                name="duration"
                value={formData.duration}
                onChange={handleChange}
                placeholder="e.g. 1-2 hours, 3 days"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select value={formData.status} onValueChange={handleStatusChange}>
                <SelectTrigger>
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              name="description"
              value={formData.description}
              onChange={handleChange}
              rows={3}
              required
            />
          </div>

          <div className="border-t pt-4">
            <h3 className="text-lg font-medium mb-4">Custom Service Form Fields</h3>

            {customFields.length > 0 && (
              <div className="space-y-4 mb-6">
                <h4 className="font-medium">Current Fields</h4>
                {customFields.map((field, index) => (
                  <div key={field.id} className="flex items-center gap-2 p-2 border rounded-md">
                    <div className="flex-1">
                      <p className="font-medium">{field.label}</p>
                      <p className="text-sm text-muted-foreground">
                        Type: {field.type} | {field.required ? "Required" : "Optional"}
                        {field.options && field.options.length > 0 && <> | Options: {field.options.join(", ")}</>}
                      </p>
                    </div>
                    <Button type="button" variant="ghost" size="icon" onClick={() => removeCustomField(field.id)}>
                      <Trash className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}

            <div className="space-y-4 border p-4 rounded-md">
              <h4 className="font-medium">Add New Field</h4>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="fieldLabel">Field Label</Label>
                  <Input
                    id="fieldLabel"
                    name="label"
                    value={newField.label}
                    onChange={handleNewFieldChange}
                    placeholder="e.g. Customer Phone"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="fieldType">Field Type</Label>
                  <Select value={newField.type} onValueChange={handleNewFieldTypeChange}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select field type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="text">Text</SelectItem>
                      <SelectItem value="number">Number</SelectItem>
                      <SelectItem value="textarea">Text Area</SelectItem>
                      <SelectItem value="checkbox">Checkbox</SelectItem>
                      <SelectItem value="radio">Radio Buttons</SelectItem>
                      <SelectItem value="select">Dropdown</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="fieldRequired"
                  checked={newField.required}
                  onCheckedChange={handleNewFieldRequiredChange}
                />
                <Label htmlFor="fieldRequired">Required field</Label>
              </div>

              {(newField.type === "select" || newField.type === "radio") && (
                <div className="space-y-2">
                  <Label>Options</Label>

                  <div className="flex gap-2">
                    <Input value={newOption} onChange={(e) => setNewOption(e.target.value)} placeholder="Add option" />
                    <Button type="button" onClick={addOption} size="sm">
                      <Plus className="h-4 w-4 mr-1" /> Add
                    </Button>
                  </div>

                  {newField.options && newField.options.length > 0 && (
                    <div className="mt-2 space-y-2">
                      {newField.options.map((option, index) => (
                        <div key={index} className="flex items-center gap-2">
                          <div className="bg-muted px-3 py-1 rounded-md flex-1">{option}</div>
                          <Button type="button" variant="ghost" size="icon" onClick={() => removeOption(index)}>
                            <Trash className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              <Button type="button" onClick={addCustomField} disabled={!newField.label.trim()}>
                Add Field
              </Button>
            </div>
          </div>

          <div className="pt-4 flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={onCancel}>
              Cancel
            </Button>
            <Button type="submit">{service ? "Update Service" : "Add Service"}</Button>
          </div>
        </form>
      </div>
    </div>
  )
}

