"use client"

import { Button } from "@/components/ui/button"
import { X, Printer } from "lucide-react"
import type { Order } from "@/lib/types"
import { Badge } from "@/components/ui/badge"

interface OrderDetailsProps {
  order: Order
  onClose: () => void
  onPrint: () => void
}

export function OrderDetails({ order, onClose, onPrint }: OrderDetailsProps) {
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-lg w-full max-w-3xl max-h-[90vh] overflow-auto">
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="text-xl font-semibold">Order Details - {order.id}</h2>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={onPrint}>
              <Printer className="h-4 w-4 mr-2" />
              Print
            </Button>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <div className="p-4 space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <h3 className="font-medium text-muted-foreground">Customer</h3>
              <p className="font-medium">{order.customer}</p>
            </div>

            <div>
              <h3 className="font-medium text-muted-foreground">Date</h3>
              <p className="font-medium">{order.date}</p>
            </div>

            <div>
              <h3 className="font-medium text-muted-foreground">Cashier</h3>
              <p className="font-medium">{order.cashier}</p>
            </div>

            <div>
              <h3 className="font-medium text-muted-foreground">Status</h3>
              <Badge
                variant={
                  order.status === "completed" ? "default" : order.status === "processing" ? "secondary" : "destructive"
                }
              >
                {order.status}
              </Badge>
            </div>
          </div>

          <div>
            <h3 className="font-medium mb-2">Products</h3>
            <div className="rounded-md border overflow-hidden">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Name
                    </th>
                    <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Price
                    </th>
                    <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Quantity
                    </th>
                    <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Total
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {order.products.map((product, index) => (
                    <tr key={index}>
                      <td className="px-4 py-2 whitespace-nowrap">{product.name}</td>
                      <td className="px-4 py-2 text-right whitespace-nowrap">${product.price.toFixed(2)}</td>
                      <td className="px-4 py-2 text-right whitespace-nowrap">{product.quantity}</td>
                      <td className="px-4 py-2 text-right whitespace-nowrap">
                        ${(product.price * product.quantity).toFixed(2)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {order.services && order.services.length > 0 && (
            <div>
              <h3 className="font-medium mb-2">Services</h3>
              <div className="rounded-md border overflow-hidden">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Name
                      </th>
                      <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Price
                      </th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Customer
                      </th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Status
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {order.services.map((service, index) => (
                      <tr key={index}>
                        <td className="px-4 py-2 whitespace-nowrap">{service.name}</td>
                        <td className="px-4 py-2 text-right whitespace-nowrap">${service.price.toFixed(2)}</td>
                        <td className="px-4 py-2 whitespace-nowrap">{service.customerName}</td>
                        <td className="px-4 py-2 whitespace-nowrap">
                          <Badge
                            variant={
                              service.status === "completed"
                                ? "default"
                                : service.status === "in-progress"
                                  ? "secondary"
                                  : "outline"
                            }
                          >
                            {service.status}
                          </Badge>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          <div className="space-y-2">
            <div className="flex justify-between">
              <span>Subtotal:</span>
              <span>${(order.total + (order.discount || 0)).toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span>Discount:</span>
              <span>${(order.discount || 0).toFixed(2)}</span>
            </div>
            <div className="flex justify-between font-bold">
              <span>Total:</span>
              <span>${order.total.toFixed(2)}</span>
            </div>
          </div>

          {order.notes && (
            <div>
              <h3 className="font-medium mb-2">Notes</h3>
              <p className="text-sm bg-gray-50 p-3 rounded-md">{order.notes}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

