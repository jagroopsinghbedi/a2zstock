import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"

export function RecentOrders() {
  const orders = [
    {
      id: "ORD-001",
      customer: "John Doe",
      amount: "$129.99",
      status: "completed",
      date: "2 hours ago",
      initials: "JD",
    },
    {
      id: "ORD-002",
      customer: "Sarah Smith",
      amount: "$89.50",
      status: "processing",
      date: "3 hours ago",
      initials: "SS",
    },
    {
      id: "ORD-003",
      customer: "Michael Brown",
      amount: "$245.00",
      status: "completed",
      date: "5 hours ago",
      initials: "MB",
    },
    {
      id: "ORD-004",
      customer: "Emily Johnson",
      amount: "$74.99",
      status: "pending",
      date: "6 hours ago",
      initials: "EJ",
    },
    {
      id: "ORD-005",
      customer: "David Wilson",
      amount: "$189.99",
      status: "completed",
      date: "8 hours ago",
      initials: "DW",
    },
  ]

  return (
    <div className="space-y-4">
      {orders.map((order) => (
        <div key={order.id} className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Avatar className="h-9 w-9">
              <AvatarFallback>{order.initials}</AvatarFallback>
            </Avatar>
            <div>
              <p className="text-sm font-medium leading-none">{order.customer}</p>
              <p className="text-sm text-muted-foreground">{order.id}</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Badge
              variant={
                order.status === "completed" ? "default" : order.status === "processing" ? "secondary" : "outline"
              }
            >
              {order.status}
            </Badge>
            <div className="text-sm text-right">
              <p className="font-medium">{order.amount}</p>
              <p className="text-muted-foreground">{order.date}</p>
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}

