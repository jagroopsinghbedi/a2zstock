"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Package2, Printer } from "lucide-react"

interface OrderSummaryProps {
  items: any[]
  onPrint: () => void
  onCancel: () => void
}

export function OrderSummary({ items, onPrint, onCancel }: OrderSummaryProps) {
  const [discount, setDiscount] = useState(0)
  const [notes, setNotes] = useState("")

  const subtotal = items.reduce((total, item) => total + item.price * (item.quantity || 1), 0)
  const tax = subtotal * 0.1
  const total = subtotal + tax - discount

  const storeInfo = {
    name: "Stock Manager Store",
    address: "123 Main Street, Anytown, USA",
    phone: "+1 (555) 123-4567",
    email: "info@stockmanager.com",
    cashier: "Emma Wilson",
  }

  return (
    <div className="bg-white p-4 rounded-lg shadow-sm">
      <div className="text-center mb-4">
        <div className="flex justify-center mb-2">
          <Package2 className="h-8 w-8" />
        </div>
        <h2 className="text-xl font-bold">{storeInfo.name}</h2>
        <p className="text-sm text-muted-foreground">{storeInfo.address}</p>
        <p className="text-sm text-muted-foreground">{storeInfo.phone}</p>
        <p className="text-sm text-muted-foreground">{storeInfo.email}</p>
      </div>

      <div className="border-t border-b py-2 mb-4">
        <div className="flex justify-between text-sm">
          <span>Date:</span>
          <span>{new Date().toLocaleDateString()}</span>
        </div>
        <div className="flex justify-between text-sm">
          <span>Time:</span>
          <span>{new Date().toLocaleTimeString()}</span>
        </div>
        <div className="flex justify-between text-sm">
          <span>Cashier:</span>
          <span>{storeInfo.cashier}</span>
        </div>
      </div>

      <div className="mb-4">
        <h3 className="font-medium mb-2">Items</h3>
        <div className="space-y-2">
          {items.map((item, index) => (
            <div key={index} className="flex justify-between text-sm">
              <div>
                <span>{item.name} </span>
                <span className="text-muted-foreground">{item.quantity ? `x${item.quantity}` : ""}</span>
              </div>
              <span>${(item.price * (item.quantity || 1)).toFixed(2)}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="space-y-2 mb-4">
        <div className="flex justify-between text-sm">
          <span>Subtotal:</span>
          <span>${subtotal.toFixed(2)}</span>
        </div>
        <div className="flex justify-between text-sm">
          <span>Tax (10%):</span>
          <span>${tax.toFixed(2)}</span>
        </div>

        <div className="flex items-center gap-2">
          <Label htmlFor="discount" className="text-sm">
            Discount:
          </Label>
          <Input
            id="discount"
            type="number"
            min="0"
            step="0.01"
            value={discount}
            onChange={(e) => setDiscount(Number.parseFloat(e.target.value) || 0)}
            className="h-8 w-24"
          />
        </div>

        <div className="flex justify-between font-bold">
          <span>Total:</span>
          <span>${total.toFixed(2)}</span>
        </div>
      </div>

      <div className="mb-4">
        <Label htmlFor="notes" className="text-sm">
          Notes:
        </Label>
        <Textarea id="notes" value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} className="mt-1" />
      </div>

      <div className="flex gap-2">
        <Button variant="outline" className="flex-1" onClick={onCancel}>
          Cancel
        </Button>
        <Button className="flex-1" onClick={onPrint}>
          <Printer className="mr-2 h-4 w-4" />
          Print
        </Button>
      </div>
    </div>
  )
}

