"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { X } from "lucide-react"
import type { Service } from "@/lib/types"
import { Checkbox } from "@/components/ui/checkbox"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface ServiceFormProps {
  service: Service
  onClose: () => void
  onSubmit: (data: any) => void
}

export function ServiceForm({ service, onClose, onSubmit }: ServiceFormProps) {
  const [customerName, setCustomerName] = useState("")
  const [customerPhone, setCustomerPhone] = useState("")
  const [formValues, setFormValues] = useState<Record<string, any>>({})

  const handleFieldChange = (fieldId: string, value: any) => {
    setFormValues((prev) => ({ ...prev, [fieldId]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const serviceData = {
      id: `SRV-ORDER-${Math.floor(Math.random() * 10000)
        .toString()
        .padStart(4, "0")}`,
      type: "service",
      serviceId: service._id,
      name: service.name,
      price: service.price,
      customerName,
      customerPhone,
      formData: formValues,
    }

    onSubmit(serviceData)
  }

  const renderField = (field: any) => {
    switch (field.type) {
      case "text":
        return (
          <Input
            id={field.id}
            value={formValues[field.id] || ""}
            onChange={(e) => handleFieldChange(field.id, e.target.value)}
            required={field.required}
          />
        )
      case "number":
        return (
          <Input
            id={field.id}
            type="number"
            value={formValues[field.id] || ""}
            onChange={(e) => handleFieldChange(field.id, e.target.value)}
            required={field.required}
          />
        )
      case "textarea":
        return (
          <Textarea
            id={field.id}
            value={formValues[field.id] || ""}
            onChange={(e) => handleFieldChange(field.id, e.target.value)}
            rows={3}
            required={field.required}
          />
        )
      case "checkbox":
        return (
          <div className="flex items-center space-x-2">
            <Checkbox
              id={field.id}
              checked={formValues[field.id] || false}
              onCheckedChange={(checked) => handleFieldChange(field.id, checked)}
            />
            <Label htmlFor={field.id}>Yes</Label>
          </div>
        )
      case "radio":
        return (
          <RadioGroup value={formValues[field.id] || ""} onValueChange={(value) => handleFieldChange(field.id, value)}>
            {field.options?.map((option: string) => (
              <div key={option} className="flex items-center space-x-2">
                <RadioGroupItem value={option} id={`${field.id}-${option}`} />
                <Label htmlFor={`${field.id}-${option}`}>{option}</Label>
              </div>
            ))}
          </RadioGroup>
        )
      case "select":
        return (
          <Select value={formValues[field.id] || ""} onValueChange={(value) => handleFieldChange(field.id, value)}>
            <SelectTrigger>
              <SelectValue placeholder="Select an option" />
            </SelectTrigger>
            <SelectContent>
              {field.options?.map((option: string) => (
                <SelectItem key={option} value={option}>
                  {option}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )
      default:
        return null
    }
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-lg w-full max-w-md max-h-[90vh] overflow-auto">
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="text-xl font-semibold">Service Details - {service.name}</h2>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 space-y-4">
          <div className="space-y-2">
            <Label htmlFor="customerName">Customer Name</Label>
            <Input id="customerName" value={customerName} onChange={(e) => setCustomerName(e.target.value)} required />
          </div>

          <div className="space-y-2">
            <Label htmlFor="customerPhone">Customer Phone</Label>
            <Input
              id="customerPhone"
              value={customerPhone}
              onChange={(e) => setCustomerPhone(e.target.value)}
              required
            />
          </div>

          {service.formFields && service.formFields.length > 0 && (
            <div className="border-t pt-4 mt-4">
              <h3 className="font-medium mb-4">Service Information</h3>

              {service.formFields.map((field) => (
                <div key={field.id} className="space-y-2 mb-4">
                  <Label htmlFor={field.id}>
                    {field.label} {field.required && <span className="text-red-500">*</span>}
                  </Label>
                  {renderField(field)}
                </div>
              ))}
            </div>
          )}

          <div className="pt-4 flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit">Add to Order</Button>
          </div>
        </form>
      </div>
    </div>
  )
}

