import { NextResponse } from "next/server"
import { getDb } from "@/lib/db"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const search = searchParams.get("search")

    const db = await getDb()
    const collection = db.collection("orders")

    const query: any = {}

    if (search) {
      query.$or = [{ id: { $regex: search, $options: "i" } }, { customer: { $regex: search, $options: "i" } }]
    }

    const orders = await collection.find(query).sort({ date: -1 }).toArray()

    return NextResponse.json(orders)
  } catch (error) {
    console.error("Error fetching orders:", error)
    return NextResponse.json({ error: "Failed to fetch orders" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const order = await request.json()

    const db = await getDb()
    const ordersCollection = db.collection("orders")
    const productsCollection = db.collection("products")

    // Update product quantities
    for (const item of order.products) {
      await productsCollection.updateOne({ _id: item.productId }, { $inc: { quantity: -item.quantity } })
    }

    const result = await ordersCollection.insertOne(order)

    return NextResponse.json({ id: result.insertedId, ...order })
  } catch (error) {
    console.error("Error creating order:", error)
    return NextResponse.json({ error: "Failed to create order" }, { status: 500 })
  }
}

