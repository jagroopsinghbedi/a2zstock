import { NextResponse } from "next/server"
import { getDb } from "@/lib/db"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const search = searchParams.get("search")

    const db = await getDb()
    const collection = db.collection("services")

    const query: any = {}

    if (search) {
      query.name = { $regex: search, $options: "i" }
    }

    const services = await collection.find(query).toArray()

    return NextResponse.json(services)
  } catch (error) {
    console.error("Error fetching services:", error)
    return NextResponse.json({ error: "Failed to fetch services" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const service = await request.json()

    const db = await getDb()
    const collection = db.collection("services")

    const result = await collection.insertOne(service)

    return NextResponse.json({ id: result.insertedId, ...service })
  } catch (error) {
    console.error("Error creating service:", error)
    return NextResponse.json({ error: "Failed to create service" }, { status: 500 })
  }
}

