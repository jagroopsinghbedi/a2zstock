import { NextResponse } from "next/server"
import { getDb } from "@/lib/db"
import bcrypt from "bcryptjs"

export async function GET(request: Request) {
  try {
    const db = await getDb()
    const collection = db.collection("users")

    const users = await collection.find({}, { projection: { password: 0 } }).toArray()

    return NextResponse.json(users)
  } catch (error) {
    console.error("Error fetching users:", error)
    return NextResponse.json({ error: "Failed to fetch users" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const userData = await request.json()

    // Hash password
    const salt = await bcrypt.genSalt(10)
    const hashedPassword = await bcrypt.hash(userData.password, salt)

    const user = {
      ...userData,
      password: hashedPassword,
      createdAt: new Date(),
    }

    const db = await getDb()
    const collection = db.collection("users")

    const result = await collection.insertOne(user)

    // Don't return the password
    const { password, ...userWithoutPassword } = user

    return NextResponse.json({ id: result.insertedId, ...userWithoutPassword })
  } catch (error) {
    console.error("Error creating user:", error)
    return NextResponse.json({ error: "Failed to create user" }, { status: 500 })
  }
}

