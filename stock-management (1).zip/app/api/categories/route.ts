import { NextResponse } from "next/server"
import { getDb } from "@/lib/db"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const search = searchParams.get("search")

    const db = await getDb()
    const collection = db.collection("categories")

    const query: any = {}

    if (search) {
      query.name = { $regex: search, $options: "i" }
    }

    const categories = await collection.find(query).toArray()

    return NextResponse.json(categories)
  } catch (error) {
    console.error("Error fetching categories:", error)
    return NextResponse.json({ error: "Failed to fetch categories" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const category = await request.json()

    const db = await getDb()
    const collection = db.collection("categories")

    const result = await collection.insertOne(category)

    return NextResponse.json({ id: result.insertedId, ...category })
  } catch (error) {
    console.error("Error creating category:", error)
    return NextResponse.json({ error: "Failed to create category" }, { status: 500 })
  }
}

