import { NextResponse } from "next/server"
import { getDb } from "@/lib/db"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const search = searchParams.get("search")
    const category = searchParams.get("category")

    const db = await getDb()
    const collection = db.collection("products")

    const query: any = {}

    if (search) {
      query.name = { $regex: search, $options: "i" }
    }

    if (category && category !== "all") {
      query.category = category
    }

    const products = await collection.find(query).toArray()

    return NextResponse.json(products)
  } catch (error) {
    console.error("Error fetching products:", error)
    return NextResponse.json({ error: "Failed to fetch products" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const product = await request.json()

    const db = await getDb()
    const collection = db.collection("products")

    const result = await collection.insertOne(product)

    return NextResponse.json({ id: result.insertedId, ...product })
  } catch (error) {
    console.error("Error creating product:", error)
    return NextResponse.json({ error: "Failed to create product" }, { status: 500 })
  }
}

