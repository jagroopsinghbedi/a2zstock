"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Search, ShoppingCart, Plus, Minus, Trash, Printer } from "lucide-react"
import { ServiceForm } from "@/components/cashier/service-form"
import type { Product, Service } from "@/lib/types"

export default function CashierPage() {
  const [activeTab, setActiveTab] = useState("all")
  const [showServiceForm, setShowServiceForm] = useState(false)
  const [cart, setCart] = useState<any[]>([])
  const [categories, setCategories] = useState<any[]>([])
  const [products, setProducts] = useState<Product[]>([])
  const [services, setServices] = useState<Service[]>([])
  const [selectedService, setSelectedService] = useState<Service | null>(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [discount, setDiscount] = useState(0)
  const [notes, setNotes] = useState("")
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    fetchCategories()
    fetchProducts()
    fetchServices()
  }, [])

  const fetchCategories = async () => {
    try {
      const response = await fetch("/api/categories")
      if (response.ok) {
        const data = await response.json()
        setCategories([{ id: "all", name: "All Products" }, ...data])
      }
    } catch (error) {
      console.error("Error fetching categories:", error)
    }
  }

  const fetchProducts = async () => {
    setIsLoading(true)
    try {
      const response = await fetch("/api/products")
      if (response.ok) {
        const data = await response.json()
        setProducts(data)
      }
    } catch (error) {
      console.error("Error fetching products:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const fetchServices = async () => {
    try {
      const response = await fetch("/api/services")
      if (response.ok) {
        const data = await response.json()
        setServices(data)
      }
    } catch (error) {
      console.error("Error fetching services:", error)
    }
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    fetchFilteredProducts()
  }

  const fetchFilteredProducts = async () => {
    setIsLoading(true)
    try {
      const categoryParam = activeTab !== "all" ? `&category=${activeTab}` : ""
      const response = await fetch(`/api/products?search=${searchTerm}${categoryParam}`)
      if (response.ok) {
        const data = await response.json()
        setProducts(data)
      }
    } catch (error) {
      console.error("Error searching products:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const addToCart = (item: any, isService = false) => {
    if (isService) {
      setSelectedService(item)
      setShowServiceForm(true)
      return
    }

    const existingItem = cart.find((cartItem) => cartItem.id === item.id)

    if (existingItem) {
      setCart(
        cart.map((cartItem) => (cartItem.id === item.id ? { ...cartItem, quantity: cartItem.quantity + 1 } : cartItem)),
      )
    } else {
      setCart([...cart, { ...item, quantity: 1 }])
    }
  }

  const removeFromCart = (id: string) => {
    setCart(cart.filter((item) => item.id !== id))
  }

  const updateQuantity = (id: string, newQuantity: number) => {
    if (newQuantity <= 0) {
      removeFromCart(id)
      return
    }

    setCart(cart.map((item) => (item.id === id ? { ...item, quantity: newQuantity } : item)))
  }

  const handleServiceSubmit = (serviceData: any) => {
    setCart([...cart, serviceData])
    setShowServiceForm(false)
    setSelectedService(null)
  }

  const calculateSubtotal = () => {
    return cart.reduce((total, item) => {
      if (item.type === "service") {
        return total + item.price
      } else {
        return total + item.salePrice * (item.quantity || 1)
      }
    }, 0)
  }

  const calculateTotal = () => {
    return calculateSubtotal() - discount
  }

  const clearCart = () => {
    setCart([])
    setDiscount(0)
    setNotes("")
  }

  const printReceipt = async () => {
    if (cart.length === 0) return

    try {
      // Create order object
      const order = {
        id: `ORD${Math.floor(Math.random() * 10000)
          .toString()
          .padStart(4, "0")}`,
        customer: "Walk-in Customer",
        date: new Date().toISOString(),
        total: calculateTotal(),
        items: cart.length,
        status: "completed",
        cashier: "Emma Wilson",
        products: cart
          .filter((item) => !item.type)
          .map((item) => ({
            productId: item._id,
            name: item.name,
            price: item.salePrice,
            quantity: item.quantity,
          })),
        services: cart
          .filter((item) => item.type === "service")
          .map((service) => ({
            serviceId: service.serviceId,
            name: service.name,
            price: service.price,
            customerName: service.customerName,
            customerPhone: service.customerPhone,
            status: "pending",
            ...service.formData,
          })),
        discount: discount,
        notes: notes,
      }

      // Save order to database
      const response = await fetch("/api/orders", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(order),
      })

      if (response.ok) {
        // Open print view in new window
        const printWindow = window.open("", "_blank")
        if (printWindow) {
          printWindow.document.write(`
            <html>
              <head>
                <title>Order Receipt - ${order.id}</title>
                <style>
                  body { font-family: Arial, sans-serif; margin: 0; padding: 20px; }
                  .receipt { max-width: 800px; margin: 0 auto; }
                  .header { text-align: center; margin-bottom: 20px; }
                  .logo { font-size: 24px; font-weight: bold; margin-bottom: 5px; }
                  .info { margin-bottom: 20px; }
                  .info-row { display: flex; justify-content: space-between; margin-bottom: 5px; }
                  table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
                  th, td { padding: 8px; text-align: left; border-bottom: 1px solid #ddd; }
                  th { background-color: #f2f2f2; }
                  .total-row { font-weight: bold; }
                  .footer { text-align: center; margin-top: 30px; font-size: 14px; color: #666; }
                  @media print {
                    body { padding: 0; }
                    button { display: none; }
                  }
                </style>
              </head>
              <body>
                <div class="receipt">
                  <div class="header">
                    <div class="logo">A2Z Stock Manager</div>
                    <div>123 Business Street, City, Country</div>
                    <div>Phone: (123) 456-7890 | Email: info@a2zstock.com</div>
                  </div>
                  
                  <div class="info">
                    <div class="info-row">
                      <div><strong>Order ID:</strong> ${order.id}</div>
                      <div><strong>Date:</strong> ${new Date().toLocaleString()}</div>
                    </div>
                    <div class="info-row">
                      <div><strong>Customer:</strong> ${order.customer}</div>
                      <div><strong>Cashier:</strong> ${order.cashier}</div>
                    </div>
                  </div>
                  
                  <table>
                    <thead>
                      <tr>
                        <th>Item</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Total</th>
                      </tr>
                    </thead>
                    <tbody>
                      ${cart
                        .map((item) => {
                          if (item.type === "service") {
                            return `
                            <tr>
                              <td>${item.name} (Service)</td>
                              <td>$${item.price.toFixed(2)}</td>
                              <td>1</td>
                              <td>$${item.price.toFixed(2)}</td>
                            </tr>
                          `
                          } else {
                            return `
                            <tr>
                              <td>${item.name}</td>
                              <td>$${item.salePrice.toFixed(2)}</td>
                              <td>${item.quantity}</td>
                              <td>$${(item.salePrice * item.quantity).toFixed(2)}</td>
                            </tr>
                          `
                          }
                        })
                        .join("")}
                      
                      <tr>
                        <td colspan="3" style="text-align: right;"><strong>Discount:</strong></td>
                        <td>$${discount.toFixed(2)}</td>
                      </tr>
                      <tr class="total-row">
                        <td colspan="3" style="text-align: right;"><strong>Total:</strong></td>
                        <td>$${calculateTotal().toFixed(2)}</td>
                      </tr>
                    </tbody>
                  </table>
                  
                  ${
                    notes
                      ? `
                    <div>
                      <strong>Notes:</strong>
                      <p>${notes}</p>
                    </div>
                  `
                      : ""
                  }
                  
                  <div class="footer">
                    <p>Thank you for your business!</p>
                  </div>
                  
                  <div style="text-align: center; margin-top: 30px;">
                    <button onclick="window.print()">Print Receipt</button>
                  </div>
                </div>
              </body>
            </html>
          `)
          printWindow.document.close()

          // Clear cart after successful print
          clearCart()
        }
      }
    } catch (error) {
      console.error("Error processing order:", error)
      alert("Failed to process order. Please try again.")
    }
  }

  return (
    <div className="flex h-full gap-4">
      {/* Categories sidebar */}
      <div className="hidden md:flex w-64 flex-col gap-2 bg-white p-4 rounded-lg shadow-sm">
        <div className="text-lg font-semibold mb-4">Categories</div>
        {categories.map((category) => (
          <Button
            key={category.id}
            variant={activeTab === category.id ? "default" : "ghost"}
            className="justify-start"
            onClick={() => {
              setActiveTab(category.id)
              fetchFilteredProducts()
            }}
          >
            {category.name}
          </Button>
        ))}
        <Button
          variant={activeTab === "services" ? "default" : "ghost"}
          className="justify-start"
          onClick={() => setActiveTab("services")}
        >
          Services
        </Button>
      </div>

      {/* Products grid */}
      <div className="flex-1 bg-white p-4 rounded-lg shadow-sm overflow-auto">
        <div className="mb-4 flex items-center gap-4">
          <form onSubmit={handleSearch} className="flex items-center gap-2 flex-1">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search products..."
                className="pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Button type="submit" variant="outline">
              Search
            </Button>
          </form>
          <Tabs value={activeTab} onValueChange={setActiveTab} className="md:hidden">
            <TabsList>
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="services">Services</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        {activeTab !== "services" ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
            {isLoading ? (
              <div className="col-span-full text-center py-8">Loading products...</div>
            ) : products.length === 0 ? (
              <div className="col-span-full text-center py-8">No products found</div>
            ) : (
              products.map((product) => (
                <Card key={product._id} className="overflow-hidden">
                  <CardContent className="p-3">
                    <div className="flex flex-col items-center text-center gap-2">
                      <div className="font-medium">{product.name}</div>
                      <div className="text-sm text-muted-foreground">${product.salePrice.toFixed(2)}</div>
                      <div className="text-xs">
                        <Badge variant={product.quantity < 10 ? "destructive" : "outline"}>
                          {product.quantity} in stock
                        </Badge>
                      </div>
                      <Button
                        className="w-full mt-2"
                        size="sm"
                        onClick={() => addToCart(product)}
                        disabled={product.quantity <= 0}
                      >
                        Add to Cart
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
            {services.length === 0 ? (
              <div className="col-span-full text-center py-8">No services found</div>
            ) : (
              services.map((service) => (
                <Card key={service._id} className="overflow-hidden">
                  <CardContent className="p-3">
                    <div className="flex flex-col items-center text-center gap-2">
                      <div className="relative">
                        <Badge className="absolute -top-2 -right-2 bg-blue-500">Service</Badge>
                      </div>
                      <div className="font-medium">{service.name}</div>
                      <div className="text-sm text-muted-foreground">${service.price.toFixed(2)}</div>
                      <Button className="w-full mt-2" size="sm" onClick={() => addToCart(service, true)}>
                        Add Service
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        )}
      </div>

      {/* Order summary */}
      <div className="w-80 bg-white p-4 rounded-lg shadow-sm flex flex-col">
        <div className="text-lg font-semibold mb-4 flex items-center">
          <ShoppingCart className="mr-2 h-5 w-5" />
          Order Summary
        </div>

        <div className="flex-1 overflow-auto">
          {cart.length === 0 ? (
            <div className="text-center text-muted-foreground py-8">Cart is empty</div>
          ) : (
            <div className="space-y-4">
              {cart.map((item) => (
                <div key={item.id} className="flex items-center gap-2">
                  <div className="flex-1 min-w-0">
                    <div className="font-medium truncate">{item.name}</div>
                    <div className="text-sm text-muted-foreground">
                      ${item.type === "service" ? item.price.toFixed(2) : item.salePrice.toFixed(2)}
                    </div>
                  </div>
                  {!item.type ? (
                    <div className="flex items-center gap-1">
                      <Button
                        variant="outline"
                        size="icon"
                        className="h-6 w-6"
                        onClick={() => updateQuantity(item.id, (item.quantity || 1) - 1)}
                      >
                        <Minus className="h-3 w-3" />
                      </Button>
                      <span className="w-6 text-center">{item.quantity || 1}</span>
                      <Button
                        variant="outline"
                        size="icon"
                        className="h-6 w-6"
                        onClick={() => updateQuantity(item.id, (item.quantity || 1) + 1)}
                      >
                        <Plus className="h-3 w-3" />
                      </Button>
                    </div>
                  ) : (
                    <Badge className="bg-blue-500">Service</Badge>
                  )}
                  <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => removeFromCart(item.id)}>
                    <Trash className="h-3 w-3" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="mt-4 pt-4 border-t">
          <div className="flex justify-between mb-2">
            <span>Subtotal</span>
            <span>${calculateSubtotal().toFixed(2)}</span>
          </div>
          <div className="flex items-center justify-between mb-4">
            <span>Discount</span>
            <Input
              type="number"
              min="0"
              step="0.01"
              value={discount}
              onChange={(e) => setDiscount(Number.parseFloat(e.target.value) || 0)}
              className="w-24 h-8 text-right"
            />
          </div>
          <div className="flex justify-between font-bold mb-4">
            <span>Total</span>
            <span>${calculateTotal().toFixed(2)}</span>
          </div>

          <div className="mb-4">
            <Input placeholder="Order notes (optional)" value={notes} onChange={(e) => setNotes(e.target.value)} />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <Button variant="outline" onClick={clearCart} disabled={cart.length === 0}>
              Clear
            </Button>
            <Button onClick={printReceipt} disabled={cart.length === 0}>
              <Printer className="mr-2 h-4 w-4" />
              Print
            </Button>
          </div>
        </div>
      </div>

      {/* Service form modal */}
      {showServiceForm && selectedService && (
        <ServiceForm
          service={selectedService}
          onClose={() => {
            setShowServiceForm(false)
            setSelectedService(null)
          }}
          onSubmit={handleServiceSubmit}
        />
      )}
    </div>
  )
}

