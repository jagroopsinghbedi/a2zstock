import type { ReactNode } from "react"
import CashierHeader from "@/components/cashier/cashier-header"

export default function CashierLayout({ children }: { children: ReactNode }) {
  return (
    <div className="flex h-screen flex-col bg-gray-100">
      <CashierHeader />
      <main className="flex-1 overflow-auto p-4">{children}</main>
    </div>
  )
}

