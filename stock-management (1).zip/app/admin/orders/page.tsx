"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Search, Eye, Printer } from "lucide-react"
import { OrderDetails } from "@/components/admin/order-details"
import type { Order } from "@/lib/types"

export default function OrdersPage() {
  const [orders, setOrders] = useState<Order[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null)
  const [isDetailsOpen, setIsDetailsOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    fetchOrders()
  }, [])

  const fetchOrders = async () => {
    setIsLoading(true)
    try {
      const response = await fetch(`/api/orders${searchTerm ? `?search=${searchTerm}` : ""}`)
      if (response.ok) {
        const data = await response.json()
        setOrders(data)
      } else {
        console.error("Failed to fetch orders")
      }
    } catch (error) {
      console.error("Error fetching orders:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    fetchOrders()
  }

  const handleViewOrder = (order: Order) => {
    setSelectedOrder(order)
    setIsDetailsOpen(true)
  }

  const handlePrintOrder = (order: Order) => {
    setSelectedOrder(order)
    // Open print view in new window
    const printWindow = window.open("", "_blank")
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>Order Receipt - ${order.id}</title>
            <style>
              body { font-family: Arial, sans-serif; margin: 0; padding: 20px; }
              .receipt { max-width: 800px; margin: 0 auto; }
              .header { text-align: center; margin-bottom: 20px; }
              .logo { font-size: 24px; font-weight: bold; margin-bottom: 5px; }
              .info { margin-bottom: 20px; }
              .info-row { display: flex; justify-content: space-between; margin-bottom: 5px; }
              table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
              th, td { padding: 8px; text-align: left; border-bottom: 1px solid #ddd; }
              th { background-color: #f2f2f2; }
              .total-row { font-weight: bold; }
              .footer { text-align: center; margin-top: 30px; font-size: 14px; color: #666; }
              @media print {
                body { padding: 0; }
                button { display: none; }
              }
            </style>
          </head>
          <body>
            <div class="receipt">
              <div class="header">
                <div class="logo">A2Z Stock Manager</div>
                <div>123 Business Street, City, Country</div>
                <div>Phone: (123) 456-7890 | Email: info@a2zstock.com</div>
              </div>
              
              <div class="info">
                <div class="info-row">
                  <div><strong>Order ID:</strong> ${order.id}</div>
                  <div><strong>Date:</strong> ${order.date}</div>
                </div>
                <div class="info-row">
                  <div><strong>Customer:</strong> ${order.customer}</div>
                  <div><strong>Cashier:</strong> ${order.cashier}</div>
                </div>
              </div>
              
              <table>
                <thead>
                  <tr>
                    <th>Item</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Total</th>
                  </tr>
                </thead>
                <tbody>
                  ${order.products
                    .map(
                      (item) => `
                    <tr>
                      <td>${item.name}</td>
                      <td>$${item.price.toFixed(2)}</td>
                      <td>${item.quantity}</td>
                      <td>$${(item.price * item.quantity).toFixed(2)}</td>
                    </tr>
                  `,
                    )
                    .join("")}
                  
                  ${
                    order.services
                      ? order.services
                          .map(
                            (service) => `
                    <tr>
                      <td>${service.name} (Service)</td>
                      <td>$${service.price.toFixed(2)}</td>
                      <td>1</td>
                      <td>$${service.price.toFixed(2)}</td>
                    </tr>
                  `,
                          )
                          .join("")
                      : ""
                  }
                  
                  <tr>
                    <td colspan="3" style="text-align: right;"><strong>Discount:</strong></td>
                    <td>$${(order.discount || 0).toFixed(2)}</td>
                  </tr>
                  <tr class="total-row">
                    <td colspan="3" style="text-align: right;"><strong>Total:</strong></td>
                    <td>$${order.total.toFixed(2)}</td>
                  </tr>
                </tbody>
              </table>
              
              ${
                order.notes
                  ? `
                <div>
                  <strong>Notes:</strong>
                  <p>${order.notes}</p>
                </div>
              `
                  : ""
              }
              
              <div class="footer">
                <p>Thank you for your business!</p>
              </div>
              
              <div style="text-align: center; margin-top: 30px;">
                <button onclick="window.print()">Print Receipt</button>
              </div>
            </div>
          </body>
        </html>
      `)
      printWindow.document.close()
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Orders</h1>
        <p className="text-muted-foreground">View and manage customer orders</p>
      </div>

      <form onSubmit={handleSearch} className="flex items-center gap-2">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search orders..."
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <Button type="submit" variant="outline">
          Search
        </Button>
      </form>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Order ID</TableHead>
              <TableHead>Customer</TableHead>
              <TableHead>Date</TableHead>
              <TableHead className="text-right">Total</TableHead>
              <TableHead className="text-right">Items</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Cashier</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell colSpan={8} className="text-center py-4">
                  Loading orders...
                </TableCell>
              </TableRow>
            ) : orders.length === 0 ? (
              <TableRow>
                <TableCell colSpan={8} className="text-center py-4">
                  No orders found
                </TableCell>
              </TableRow>
            ) : (
              orders.map((order) => (
                <TableRow key={order._id}>
                  <TableCell className="font-medium">{order.id}</TableCell>
                  <TableCell>{order.customer}</TableCell>
                  <TableCell>{order.date}</TableCell>
                  <TableCell className="text-right">${order.total.toFixed(2)}</TableCell>
                  <TableCell className="text-right">{order.items}</TableCell>
                  <TableCell>
                    <Badge
                      variant={
                        order.status === "completed"
                          ? "default"
                          : order.status === "processing"
                            ? "secondary"
                            : "destructive"
                      }
                    >
                      {order.status}
                    </Badge>
                  </TableCell>
                  <TableCell>{order.cashier}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button variant="ghost" size="icon" onClick={() => handleViewOrder(order)}>
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => handlePrintOrder(order)}>
                        <Printer className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      {isDetailsOpen && selectedOrder && (
        <OrderDetails
          order={selectedOrder}
          onClose={() => setIsDetailsOpen(false)}
          onPrint={() => handlePrintOrder(selectedOrder)}
        />
      )}
    </div>
  )
}

