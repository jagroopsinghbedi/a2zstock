import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Package2 } from "lucide-react"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-r from-blue-50 to-indigo-50">
      <div className="w-full max-w-md space-y-8 p-8 bg-white rounded-xl shadow-lg">
        <div className="text-center">
          <div className="flex justify-center mb-4">
            <Package2 className="h-12 w-12 text-blue-600" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900">A2Z Stock Manager</h1>
          <p className="mt-2 text-gray-600">Manage your inventory, services, and sales</p>
        </div>
        <div className="space-y-4 pt-4">
          <Button asChild className="w-full bg-blue-600 hover:bg-blue-700">
            <Link href="/login">Login</Link>
          </Button>
        </div>
      </div>
    </div>
  )
}

